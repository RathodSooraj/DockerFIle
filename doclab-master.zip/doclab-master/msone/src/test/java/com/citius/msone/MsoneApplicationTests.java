package com.citius.msone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
