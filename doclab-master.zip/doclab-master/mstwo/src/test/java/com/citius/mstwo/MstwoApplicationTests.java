package com.citius.mstwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MstwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
