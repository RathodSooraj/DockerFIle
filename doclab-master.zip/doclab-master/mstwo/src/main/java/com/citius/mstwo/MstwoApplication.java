package com.citius.mstwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MstwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MstwoApplication.class, args);
	}

}
